package com.skillenza.parkinglotjava;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class ParkingLotController {

	// your code goes here
	@Autowired
	private ParkingLotRepository parkingLotRepository; 
    
	@GetMapping("/parkings")
	public List<ParkingLot> getAllParkings()
	{
		return parkingLotRepository.findAll();
	}
	
	@PostMapping("/parkings")
	public List<ParkingLot> saveParking(@RequestBody ParkingLot parkingLot)
	{
		parkingLot.setCreatedAt(new Date());
		parkingLot.setUpdatedAt(new Date());
		parkingLotRepository.save(parkingLot);
		return getAllParkings();
	}
}