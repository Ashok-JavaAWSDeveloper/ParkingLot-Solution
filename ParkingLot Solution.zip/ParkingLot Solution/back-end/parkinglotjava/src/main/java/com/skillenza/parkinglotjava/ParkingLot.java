package com.skillenza.parkinglotjava;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GeneratorType;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "parkinglots",
uniqueConstraints = {
		@UniqueConstraint(columnNames = "lot"),
        @UniqueConstraint(columnNames = "vehicle_number")
	})
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(value = {"createdAt", "updatedAt"}, allowGetters = true)
public class ParkingLot {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull
    private int id;
	@NotNull
	@Column(name = "created_at")
    private Date createdAt;
	@NotNull
//	@Column(unique = true)
    private int lot;
	@NotNull
	@Column(name = "parking_amount")
    private int parkingAmount;
	@NotNull
	@Column(name = "parking_duration")
    private int parkingDuration;
	@NotNull
	@Column(name = "updated_at")
    private Date updatedAt;
	@NotNull
	@Column(name = "vehicle_number")
    private int vehicleNumber;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public int getLot() {
		return lot;
	}
	public void setLot(int lot) {
		this.lot = lot;
	}
	public int getParkingAmount() {
		return parkingAmount;
	}
	public void setParkingAmount(int parkingAmount) {
		this.parkingAmount = parkingAmount;
	}
	public int getParkingDuration() {
		return parkingDuration;
	}
	public void setParkingDuration(int parkingDuration) {
		this.parkingDuration = parkingDuration;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public int getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(int vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
}