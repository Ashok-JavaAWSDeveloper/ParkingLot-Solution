import { Component,ErrorHandler } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements ErrorHandler{

  parkings;
  error_message = '';
  errorAlert = false;
  constructor(private http: HttpClient) {
    this.http.get('http://localhost:8080/api/parkings')
    .subscribe(res => {
      console.log("const res--",res) ;
      this.parkings = res;
    });
  }
  
  // your code goes here
  vehicleForm = new FormGroup ({
    lot: new FormControl(),
    vehicleNumber: new FormControl(),
    parkingDuration: new FormControl(),
    parkingAmount: new FormControl(),
  });

  onSubmit(){
    this.errorAlert = false;
    if (this.vehicleForm.valid)
    {
      this.http.post('http://localhost:8080/api/parkings', this.vehicleForm.value)
      .subscribe(res => {
       if(res)
       {
          this.parkings = res;
          this.vehicleForm.reset();
       }
      },error => {this.handleError(error)});
    }
      
  }
 
  duration : number;
  parkingAmount : number;
  calculateAmount(event : any)
  {
    this.parkingAmount = 20;
    this.duration = event.target.value;
    if(this.duration > 60)
    {
      this.duration = this.duration - 60;
      this.parkingAmount = this.parkingAmount + (this.duration * 0.333);
    }
    this.vehicleForm.patchValue({parkingAmount : this.parkingAmount});
  }
  
  handleError(error : any)
  {
    console.log(error);
    this.errorAlert = true;
    this.error_message = 'Vehicle Already Parked'
  }
}

// export class Vahicle {
//   public id : number;
//   public lot : number;
//   public parkingAmount : number;
//   public parkingDuration : number;
//   public vehicleNumber : number;
//   }


